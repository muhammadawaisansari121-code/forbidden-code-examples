# Chapter 2: The Temptation of Speed – Shipping Without Ethics

This folder contains 7 Python example(s) from this chapter.
