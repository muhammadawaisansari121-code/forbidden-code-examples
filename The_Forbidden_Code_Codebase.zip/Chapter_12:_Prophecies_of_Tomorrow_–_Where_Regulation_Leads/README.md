# Chapter 12: Prophecies of Tomorrow – Where Regulation Leads

This folder contains 24 Python example(s) from this chapter.
