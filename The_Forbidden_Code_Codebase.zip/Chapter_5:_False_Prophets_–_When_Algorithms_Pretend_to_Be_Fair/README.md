# Chapter 5: False Prophets – When Algorithms Pretend to Be Fair

This folder contains 18 Python example(s) from this chapter.
