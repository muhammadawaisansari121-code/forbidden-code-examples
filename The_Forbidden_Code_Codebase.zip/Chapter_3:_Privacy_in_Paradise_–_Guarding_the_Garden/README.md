# Chapter 3: Privacy in Paradise – Guarding the Garden

This folder contains 20 Python example(s) from this chapter.
