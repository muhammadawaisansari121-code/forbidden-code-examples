# Chapter 1: The Seeds of Creation – Data as the Fruit of Eden

This folder contains 5 Python example(s) from this chapter.
