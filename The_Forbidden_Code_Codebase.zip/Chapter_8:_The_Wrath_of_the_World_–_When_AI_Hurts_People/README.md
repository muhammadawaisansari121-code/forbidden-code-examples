# Chapter 8: The Wrath of the World – When AI Hurts People

This folder contains 6 Python example(s) from this chapter.
